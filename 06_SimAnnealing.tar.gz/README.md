##   Simulated Annealing  ##

Start this program with:

``` $ ./annealing``` (without arguments)

- First: Load a HIN-File with this program

- Second: Set the count of loops for simulated annealing

 -> create a new HIN-File with simulated annealing

 -> create a file with optimum data each loop with simulated annealing


